import re

def Parse(indices,points,packet):
    location = "packet" + packet + ".txt"
    try:
        file = open(location, encoding="utf8")
        packetText = file.read().splitlines()
        file.close()
        print("got file")
        TU = 1
        i = 0
        line = 10 # start at text[10] which will be TU1
        while TU < 21:
            print("\n")
            print("TU" + str(TU))
            TUdone = False
            TUtext = packetText[line]
            TUsplit = TUtext.split()
            print(TUtext)
            print(packetText[line+1])
            print("")
            while not TUdone:
                # because of 0-indexing, actual buzz word is [indices[i]-1]
                buzzpoint = TUsplit[indices[i]-4] + " " + TUsplit[indices[i]-3] + " " + TUsplit[indices[i]-2] + " " + TUsplit[indices[i]-1]
                print(buzzpoint + " (*) (for " + points[i] + ")")
                
                if points[i] == "15" or points[i] == "10":
                    TUdone = True
                    TU += 1
                    line += 3 # goes to next TU in txt file
                elif points[i+1] == "0": # unambiguously dead, skip
                    TUdone = True
                    TU += 1
                    line += 3
                    i += 1 # extra skip
                    print("dead")
                
                i += 1
    except:
        print("couldn't open packet file")

def Extract(text,packet):
    indices = []
    points = []
    indicesInput = re.findall("word_index.*?}",text)
    for i in indicesInput:
        indices.append(int(i[12:][:-1]))
    pointsInput = re.findall("result.*?}",text)
    for i in pointsInput:
        points.append(i[17:][:-1])
    Parse(indices,points,packet)

def GetFileText():
    valid = False
    while not valid:
        filePath = input("Enter the file path. ")
        packet = input("Enter the packet number. ")
        try:
            file = open(filePath, "r")
            text = file.read()
            file.close()
            valid = True
            Extract(text,packet)
        except:
            print("Invalid file path. Please retry.")


GetFileText()
